package servicios;

public interface Elementos {

}
