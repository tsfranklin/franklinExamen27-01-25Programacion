package servicios;
import java.util.Date;
import java.util.Scanner;
public class Elemento {
	
	long idElemento;
	private String codigoElemento;
	private String nombreelemento;
	private String descripcionElemento;
	int cantidadElemento;
	String fchAlta;
	String fchaBaja;
	
	
	///String codigoElemento = String.valueOf(idElemento);
	
	
	//constructor 
	
	public Elemento(long id,String nombre, int cantidad){
		this.idElemento= id ;
		this.nombreelemento = nombre;
		this.cantidadElemento = cantidad;
		
		
	//public void funcionamientoDeAlta();
	
	
		
		
	
		
		
	}
	
	
	
	
	

}
